    class Tdate
    {
        private int _jour;
        private int _mois;
        private int _annee;

        public int Jour
        {
            get { return _jour; }
            set { _jour = value; }
        }
        public int Mois
        {
            get { return _mois; }
            set { _mois = value; }
        }
        public int Annee
        {
            get { return _annee; }
            set { _annee = value; }
        }

        public Tdate(int p_jour, int p_mois, int p_annee)
        {
            _jour = p_jour;
            _mois = p_mois;
            _annee = p_annee;
        }

        public int DateDiff(Tdate uneDate)
        {
            int age = 0;
            if (annee >= uneDate.Annee)
            {
                if (mois > uneDate.Mois) 
                    age = annee - uneDate.Annee;
                else if (mois == uneDate.Mois) 
                {
                    if (jour >= uneDate.Jour) 
                        age = annee - uneDate.Annee;
                    else 
                        age = annee - uneDate.Annee - 1;
                }
                else 
                    age = annee - uneDate.Annee - 1;
            }
            return age;
        }

        public string Afficher()
        {
            return _jour.ToString() + "/" + _mois.ToString() + "/" + _annee.ToString();
        }
    }