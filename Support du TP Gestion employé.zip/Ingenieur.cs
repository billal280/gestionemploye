	class Ingenieur : Employe
    {
        private float _interessement;

        public float Interessement
        {
            get { return _interessement; }
            set { _interessement = value; }
        }

        public Ingenieur(Tdate p_date, int p_num, string p_nom, string p_prenom, Tdate p_dateNais, float p_salaire, float p_interessement)
            : base(p_date, p_num, p_nom, p_prenom, p_dateNais, p_salaire)
        {
            interessement = p_interessement;
        }

        public override string Afficher()
        {
            return base.NuMat.ToString() + Environment.NewLine
                + base.Nom.ToUpper() + " " + base.Prenom + Environment.NewLine
                + base.DateNais.Afficher() + Environment.NewLine
                + base.DateEmbauche.DateDiff(DateNais) + Environment.NewLine
                + base.DateEmbauche.Afficher() + Environment.NewLine
                + this.GetType().Name + Environment.NewLine
                + base.Salaire + Environment.NewLine
                + "---" + Environment.NewLine
                + interessement.ToString();
        }
    }