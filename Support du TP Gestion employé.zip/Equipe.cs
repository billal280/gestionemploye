    class Equipe
    {
        private List<Employe> _lesEmployes;

        public List<Employe> uneEquipe
        {
            get { return _lesEmployes; }
            set { _lesEmployes = value; }
        }
        public Equipe()
        {
            _lesEmployes = new List<Employe>();
        }
        public void Ajouter(Employe p_employe)
        {
            _lesEmployes.Add(p_employe);
        }
        public bool Supprimer(Employe p_employe)
        {
            if (_lesEmployes.Contains(p_employe))
            {
                _lesEmployes.Remove(p_employe);
                return true;
            }
            else
                return false;
        }
    }

