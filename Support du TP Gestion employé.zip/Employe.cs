 abstract class Employe
 {
	private int _nuMat;
    private string _nom;
    private string _prenom;
    private double _salaire;
    private Tdate _dateNais;
    private Tdate _dateEmbauche;
    public double Salaire
    {
        get { return _salaire; }
        set { _salaire = value; }
    }
    public Tdate DateNais
    {
        get { return _dateNais; }
        set { _dateNais = value; }
    }
    public Tdate DateEmbauche
    {
        get { return _dateEmbauche; }
        set { _dateEmbauche = value; }
    }
    public int NuMat
    {
        get { return _nuMat; }
        set { _nuMat = value; }
    }
    public string Nom
    {
        get { return _nom; }
        set { _nom = value; }
    }
    public string Prenom
    {
        get { return _prenom; }
        set { _prenom = value; }
    }
    public string NomComplet
    {
        get { return _prenom + _nom; }
    }
    public Employe(Tdate p_date, int p_num, string p_nom, string p_prenom, Tdate p_dateNais, float p_salaire)
	{
		_nuMat = p_num;
        _nom = p_nom;
        _prenom = p_prenom;
		_salairealaire = p_salaire;
        _dateNais = p_dateNais;
        _dateEmbauche = p_date;
    }
    public void AugSalaire(double p_Augt)
    {
         _salaire = (1+_Augt)*_salaire 
    }
    public virtual string Afficher()
    {
        return "";
    }
 }