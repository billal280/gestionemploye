	class Ouvrier : Employe
    {
        private int _numAtelier;

        public int NumAtelier
        {
            get { return _numAtelier; }
            set { _numAtelier = value; }
        }

        public Ouvrier(Tdate p_date, int p_num, string p_nom, string p_prenom, Tdate p_dateNais, float p_salaire, int p_nuAtelier)
            : base(p_date, p_num, p_nom, p_prenom, p_dateNais, p_salaire)
        {
			   nuAtelier = p_nuAtelier;            
        }

        public override string Afficher()
        {
            return base.NuMat.ToString() + Environment.NewLine
                + base.Nom.ToUpper() + " " + base.Prenom + Environment.NewLine
                + base.DateNais.Afficher() + Environment.NewLine
                + base.DateEmbauche.DateDiff(DateNais) + Environment.NewLine
                + base.DateEmbauche.Afficher() + Environment.NewLine
                + this.GetType().Name + Environment.NewLine
                + base.Salaire + Environment.NewLine
                + nuAtelier.ToString() + Environment.NewLine
                + "---";
        }
    }